package com.chairul.githubuser

import android.app.SearchManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.item_list_user.view.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.view.View.OnAttachStateChangeListener
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.chairul.githubuser.db.DatabaseContract
import com.chairul.githubuser.db.DatabaseContract.UserColumns.Companion.CONTENT_URI
import com.chairul.githubuser.db.MappingHelper
import com.chairul.githubuser.db.UserHelper
import com.chairul.githubuser.entity.SearchUser
import com.chairul.githubuser.entity.User
import com.chairul.githubuser.entity.UserDTO
import com.chairul.githubuser.entity.UserURL
import com.chairul.githubuser.view.DetailActivity
import com.chairul.githubuser.viewModel.MainViewModel
import com.chairul.githubuser.webservice.ClientBuilder


class MainActivity : AppCompatActivity() {

    private lateinit var adapter: UserAdapter
    var allUser = ArrayList<UserURL>()
    private lateinit var mainViewModel: MainViewModel
    private lateinit var userHelper: UserHelper
    var listUser = ArrayList<User>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.v("ADX", "MAIN ON CREATE")
        setContentView(R.layout.activity_main)
        adapter = UserAdapter()
        adapter.notifyDataSetChanged()
        val context = applicationContext
        userHelper = UserHelper.getInstance(context)
        userHelper.open()
        val handlerThread = HandlerThread("DataObserver")
        handlerThread.start()
        val handler = Handler(handlerThread.looper)
        val myObserver = object : ContentObserver(handler) {
            override fun onChange(self: Boolean) {
                checkSQL()
            }
        }

        contentResolver.registerContentObserver(CONTENT_URI, true, myObserver)
        //checkSQL()

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        mainViewModel = ViewModelProvider(
            this,
            ViewModelProvider.NewInstanceFactory()
        ).get(MainViewModel::class.java)

        showLoading(true)
        mainViewModel.setAllUser()

        viewModelGetAllUser()

    }

    private fun checkSQL() {

        /*GlobalScope.launch(Dispatchers.Main) {
            val deferredUsers = async(Dispatchers.IO) {
                val cursor = userHelper.queryAll()
                Log.v("ADX","Cursor $cursor")
                MappingHelper.mapCursorToArrayList(cursor)
            }
            listUser = deferredUsers.await()
        }

         */
        val cursor = contentResolver?.query(CONTENT_URI, null, null, null, null)
        listUser = MappingHelper.mapCursorToArrayList(cursor)
        Log.v("ADX","Check SQL List $listUser")
    }

    fun viewModelGetAllUser() {
        mainViewModel.getAllUser().observe(this, Observer { itemAllUser ->
            if (itemAllUser != null) {
                adapter.setData(itemAllUser)
                showLoading(false)
            }
        })

    }

    override fun onDestroy() {
        super.onDestroy()
        userHelper.close()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.option_menu, menu)

        val searchManager = getSystemService(Context.SEARCH_SERVICE) as SearchManager
        val searchView = menu!!.findItem(R.id.search).actionView as SearchView

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = resources.getString(R.string.search_hint)

        searchView.addOnAttachStateChangeListener(object : OnAttachStateChangeListener {

            override fun onViewDetachedFromWindow(arg0: View) {
                Log.v("ADX", "Search View is Close")
                recyclerView.visibility = View.VISIBLE
                showLoading(true)
                viewModelGetAllUser()
                showLoading(false)
            }

            override fun onViewAttachedToWindow(arg0: View) {
            }
        })

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {

                mainViewModel.setUserSearch(query)

                mainViewModel.getUserSearch().observe(this@MainActivity, Observer {
                    if (it != null) {
                        showUserSearch(it)
                    }
                })

                return true
            }

            override fun onQueryTextChange(newText: String): Boolean {
                return false
            }
        })
        return true
    }

    private fun showUserSearch(it: SearchUser?) {
        if (it!!.total_count == 0) {
            recyclerView.visibility = View.GONE
            adapter.setData(allUser)
        } else {
            Log.v("ADX", "List User Search \n " + it)
            adapter.setData(it.items)
            recyclerView.visibility = View.VISIBLE
        }

    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

    private fun getAllUser() {
        showLoading(true)
        try {
            ClientBuilder().services.getAllUsers().enqueue(object :
                Callback<ArrayList<UserURL>> {
                override fun onFailure(call: Call<ArrayList<UserURL>>, t: Throwable) {
                    Log.v("ADX", "FailGetUser : $t")
                    showLoading(false)
                }

                override fun onResponse(
                    call: Call<ArrayList<UserURL>>,
                    response: Response<ArrayList<UserURL>>
                ) {
                    if (response.code() == 200) {
                        response.body().let {
                            showUserList(it)
                        }
                    }
                    showLoading(false)
                }

            })
        } catch (e: Exception) {
            Log.v("ADX", "Error $e")
        }
    }

    private fun showUserList(list: ArrayList<UserURL>?) {
        try {
            Log.v("ADX", "List User \n " + list)
            adapter.setData(list!!)
            allUser = list
        }catch (e: Exception){}
    }


    @Suppress("DEPRECATION")
    inner class UserAdapter : RecyclerView.Adapter<UserAdapter.UserViewHolder>() {

        private val mData = ArrayList<UserURL>()
        fun setData(items: ArrayList<UserURL>) {
            showLoading(true)
            mData.clear()
            mData.addAll(items)
            notifyDataSetChanged()
            showLoading(false)
        }


        override fun onCreateViewHolder(viewGroup: ViewGroup, position: Int): UserViewHolder {
            val mView = LayoutInflater.from(viewGroup.context)
                .inflate(R.layout.item_list_user, viewGroup, false)
            return UserViewHolder(mView)
        }

        override fun getItemCount(): Int = mData.size

        override fun onBindViewHolder(userViewHolder: UserViewHolder, position: Int) {
            if (position % 2 == 0) userViewHolder.itemView.itemUser.setBackgroundColor(
                resources.getColor(
                    R.color.blue1
                )
            )
            else userViewHolder.itemView.itemUser.setBackgroundColor(resources.getColor(R.color.blue2))
            userViewHolder.reqUserData(mData[position].url)
            val username = mData[position].url.split("/users/")[1]
            userViewHolder.itemView.setOnClickListener { goToDetailUser(username) }
        }

        private fun goToDetailUser(username: String) {
            val intent = Intent(this@MainActivity, DetailActivity::class.java)
            intent.putExtra(DetailActivity.DETAIL_USER, username)
            startActivity(intent)
        }


        inner class UserViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            fun bind(user: UserDTO?) {
                showLoading(true)
                Log.v("ADX", "Data User \n" + user)
                if (user?.name != null) {
                    with(itemView) {
                        txtNama.text = user?.name
                        if (user?.company != null) txtCompany.text =
                            user?.company else txtCompany.text = "No Company"
                        txtUsername.text = user?.login + "@github.com"
                        Glide.with(context).load(user?.avatar_url).into(imgUser)
                    }
                }
                showLoading(false)
            }

            fun reqUserData(user: String) {
                showLoading(true)
                val name = user.split("/users/")[1]
                try {
                    ClientBuilder().services.getUserDetail(name).enqueue(object :
                        Callback<UserDTO> {
                        override fun onFailure(call: Call<UserDTO>, t: Throwable) {
                            Log.v("ADX", "FailGetUser : $t")
                            showLoading(false)
                        }

                        override fun onResponse(
                            call: Call<UserDTO>,
                            response: Response<UserDTO>
                        ) {
                            if (response.code() == 200) {
                                response.body().let {
                                    bind(it)
                                    insetToSQL(it)
                                }
                            }
                            showLoading(false)
                        }

                    })
                } catch (e: Exception) {
                    Log.v("ADX", "Error $e")
                    showLoading(false)
                }

            }


        }

        private fun deleteUser(user: UserDTO?){
            val uriWithId = Uri.parse(CONTENT_URI.toString() + "/" + user?.id)
            contentResolver.delete(uriWithId, null, null)
            Toast.makeText(this@MainActivity, "Satu item berhasil dihapus", Toast.LENGTH_SHORT).show()
            finish()
        }


        private fun insetToSQL(user: UserDTO?) {
            try {

                val filter = listUser.find { it.login == user!!.login }
                if (filter == null) {
                    Log.v("ADX", "Insert TO SQL")
                    val values = ContentValues()
                    values.put(DatabaseContract.UserColumns.LOGIN, user?.login)
                    values.put(DatabaseContract.UserColumns.NAME, user?.name ?: "-")
                    values.put(DatabaseContract.UserColumns.COMPANY, user?.company ?: "No Company" )
                    values.put(DatabaseContract.UserColumns.AVATAR_URL, user?.avatar_url ?: "-")
                    /*values.put(DatabaseContract.UserColumns.TYPE, user?.type)
                    values.put(DatabaseContract.UserColumns.NAME, user?.name)
                    values.put(DatabaseContract.UserColumns.COMPANY, user?.company)
                    values.put(DatabaseContract.UserColumns.BLOG, user?.blog)
                    values.put(DatabaseContract.UserColumns.LOCATION, user?.location)
                    values.put(DatabaseContract.UserColumns.ORGANIZATION, user?.organization)
                    values.put(DatabaseContract.UserColumns.EMAIL, user?.email)
                    values.put(DatabaseContract.UserColumns.AVATAR_URL, user?.avatar_url)
                    values.put(DatabaseContract.UserColumns.FOLLOWERS, user?.followers)
                    values.put(DatabaseContract.UserColumns.FOLLOWING, user?.following)

                     */
                    val result = userHelper.insert(values)
                    Log.v("ADX","Result Inset $result")
                    listUser = MappingHelper.mapCursorToArrayList(userHelper.queryAll())
                    Log.v("ADX","List User SQL (${listUser.size}) : \n $listUser")
                }
            } catch (e: Exception) {
                Log.v("ADX", "ERORR Insert $e")
            }
        }
    }
}
