package com.chairul.githubuser.db

import android.database.Cursor
import com.chairul.githubuser.entity.User

object MappingHelper {


    fun mapCursorToArrayList(notesCursor: Cursor?): ArrayList<User> {
        val notesList = ArrayList<User>()
        notesCursor?.apply {
            while (moveToNext()) {
                val id = getInt(getColumnIndexOrThrow(DatabaseContract.UserColumns._ID))
                val login = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.LOGIN))
                val name = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.NAME))
                val company = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.COMPANY))
                val avatar_url = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.AVATAR_URL))
                notesList.add(
                    User(
                        id,
                        login,
                        name,
                        company,
                        avatar_url
                    )
                )

            }
        }
        return notesList
    }

    fun mapCursorToObject(notesCursor: Cursor?): User {
        lateinit var user: User
        notesCursor?.apply {
            moveToFirst()
            val id = getInt(getColumnIndexOrThrow(DatabaseContract.UserColumns._ID))
            val login = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.LOGIN))
            val name = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.NAME))
            val company = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.COMPANY))
            val avatar_url = getString(getColumnIndexOrThrow(DatabaseContract.UserColumns.AVATAR_URL))
            user = User(
                id,
                login,
                name,
                company,
                avatar_url
            )
        }
        return user
    }
}