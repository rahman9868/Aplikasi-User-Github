package com.chairul.githubuser.view

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.chairul.githubuser.FollowerFragment
import com.chairul.githubuser.FollowingFragment
import com.chairul.githubuser.R
import com.chairul.githubuser.entity.UserDTO
import com.chairul.githubuser.viewModel.MainViewModel
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    var countFollower = 0
    var countFollowing = 0
    private lateinit var mainViewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val sectionsPagerAdapter = SectionsPagerAdapter(this, supportFragmentManager)
        view_pager.adapter = sectionsPagerAdapter
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.elevation = 0f
        supportActionBar?.title = "Detail User"
        username = intent.getStringExtra(
            DETAIL_USER
        )
        tabs.setupWithViewPager(view_pager)
        mainViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            MainViewModel::class.java)
        showLoading(true)
        mainViewModel.setDetailUser(username)


        mainViewModel.getDetailUser().observe(this, Observer { itemUser ->
            if(itemUser != null){
                fetcUserData(itemUser)
                showLoading(false)
            }

        })



    }

    private fun showLoading(state: Boolean) {
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }


    private fun fetcUserData(it: UserDTO?) {
        try {
            countFollower = it?.followers ?: 0
            countFollowing = it?.following ?: 0
            Glide.with(applicationContext).load(it?.avatar_url).into(detailImg)
            detailUser.text = it?.login+"@github.com"
            detailName.text = it?.name
            detailEmail.text = it?.email ?: "no email"
            detailLocation.text = it?.location ?: "no location"
            detailOrg.text = it?.organization ?: "no organization"
        } catch (e: Exception){
            Log.v("ADX","FetchUser Error $e")
        }
    }


    inner class SectionsPagerAdapter(private val mContext: Context, fm: FragmentManager) : FragmentPagerAdapter(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT) {
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_1,
            R.string.tab_text_2
        )

        override fun getItem(position: Int): Fragment {
            var fragment: Fragment? = null
            when (position) {
                0 -> fragment = FollowerFragment()
                1 -> fragment = FollowingFragment()
            }
            return fragment as Fragment
        }

        override fun getCount(): Int {
            return 2
        }

        @Nullable
        override fun getPageTitle(position: Int): CharSequence? {
            if(position == 0 && countFollower > 0)return "Follower ($countFollower)"
            else if(position == 1 && countFollowing > 0)return "Follower ($countFollowing)"
            else return mContext.resources.getString(TAB_TITLES[position])
        }

    }

    companion object{
        var DETAIL_USER = "DETAIL USER"
        var username = ""
    }
}
