package com.chairul.githubuser.view

import android.content.ContentValues
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.chairul.githubuser.R
import com.chairul.githubuser.db.DatabaseContract.UserColumns.Companion.AVATAR_URL
import com.chairul.githubuser.db.DatabaseContract.UserColumns.Companion.COMPANY
import com.chairul.githubuser.db.DatabaseContract.UserColumns.Companion.CONTENT_URI
import com.chairul.githubuser.db.DatabaseContract.UserColumns.Companion.LOGIN
import com.chairul.githubuser.db.DatabaseContract.UserColumns.Companion.NAME

class AddUserActivity : AppCompatActivity() {
    private lateinit var uriWithId: Uri

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_user)
    }

    fun addUser(){
        val values = ContentValues()
        values.put(LOGIN, "")
        values.put(NAME, "")
        values.put(COMPANY, "")
        values.put(AVATAR_URL,"")

        contentResolver.insert(CONTENT_URI, values)
        Toast.makeText(this, "Satu item berhasil disimpan", Toast.LENGTH_SHORT).show()
        finish()
    }
}
